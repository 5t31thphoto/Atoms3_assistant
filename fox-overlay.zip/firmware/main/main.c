#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "config_store.h"
#include "audio_echo.h"
#include "fox_avatar.h"
#include "tools.h"
#include "llm_client.h"

static const char *TAG = "fox";
#ifndef FOX_NAME
#define FOX_NAME "Ember"
#endif
#ifndef FOX_MODE
#define FOX_MODE "groq"
#endif

void app_main(void)
{
    ESP_LOGI(TAG, "Fox starting — name=%s mode=%s", FOX_NAME, FOX_MODE);
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        nvs_flash_erase();
        nvs_flash_init();
    }
    esp_netif_init();
    esp_event_loop_create_default();

    fox_config_t cfg;
    config_load(&cfg);
    if (cfg.fox_name[0] == '\0') strncpy(cfg.fox_name, FOX_NAME, sizeof(cfg.fox_name) - 1);

    fox_avatar_init(cfg.fox_name, cfg.color_primary, cfg.color_accent);
    fox_avatar_show_splash(cfg.splash_text[0] ? cfg.splash_text : "Hello!");
    audio_echo_init();
    tools_init(&cfg);
    llm_client_init(&cfg);

    ESP_LOGI(TAG, "Ready. Long-press button for PTT.");
    while (1) vTaskDelay(pdMS_TO_TICKS(1000));
}
