#include "audio_echo.h"
#include "esp_log.h"
#include <string.h>
#include <stdlib.h>
static const char *TAG = "audio";
static float last_amp = 0.f;
static bool ptt_active = false;
void audio_echo_init(void) {
    ESP_LOGI(TAG, "Atomic Echo stub — integrate M5Atomic-EchoBase / ES8311 for real I/O");
}
void audio_echo_set_volume(uint8_t percent) { ESP_LOGI(TAG, "Vol %u%%", percent); }
int audio_echo_record(int16_t *buf, size_t samples, int timeout_ms) {
    if (!buf || !samples) return -1;
    memset(buf, 0, samples * sizeof(int16_t));
    return (int)samples;
}
int audio_echo_play(const int16_t *buf, size_t samples) {
    if (!buf || !samples) return -1;
    int64_t sum = 0;
    for (size_t i = 0; i < samples; i++) sum += abs(buf[i]);
    last_amp = (float)sum / (samples * 32768.f);
    return (int)samples;
}
float audio_echo_last_amplitude(void) { return last_amp; }
void audio_echo_start_ptt(void) { ptt_active = true; }
void audio_echo_stop_ptt(void) { ptt_active = false; }
bool audio_echo_is_ptt_active(void) { return ptt_active; }
