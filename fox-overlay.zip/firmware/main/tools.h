#pragma once
#include "config_store.h"
void tools_init(const fox_config_t *cfg);
const char *tool_ble_radar(void);
const char *tool_wifi_scan(void);
const char *tool_ir_send(const char *code_hex);
const char *tool_imu_gesture(void);
void tools_menu_ble_radar(void);
void tools_menu_wifi(void);
