#include "fox_avatar.h"
#include "esp_log.h"
#include <string.h>
static const char *TAG = "avatar";
static char fox_name[17] = "Ember";
static char emotion[16] = "idle";
static float mouth = 0.f;
void fox_avatar_init(const char *name, const char *primary, const char *accent) {
    if (name && name[0]) strncpy(fox_name, name, sizeof(fox_name) - 1);
    ESP_LOGI(TAG, "Avatar %s", fox_name);
}
void fox_avatar_show_splash(const char *text) { ESP_LOGI(TAG, "Splash: %s", text ? text : ""); }
void fox_avatar_set_emotion(const char *e) { if (e) strncpy(emotion, e, sizeof(emotion) - 1); }
void fox_avatar_set_mouth(float open) { mouth = open < 0 ? 0 : (open > 1 ? 1 : open); }
void fox_avatar_tick(void) {}
