#include "tools.h"
#include "esp_log.h"
#include <stdio.h>
#include <string.h>
static const char *TAG = "tools";
static fox_config_t local_cfg;
void tools_init(const fox_config_t *cfg) { if (cfg) local_cfg = *cfg; ESP_LOGI(TAG, "Tools init"); }
const char *tool_ble_radar(void) {
    static char buf[256];
    snprintf(buf, sizeof(buf), "{\"devices\":[{\"name\":\"demo\",\"rssi\":-55,\"bearing\":30}],\"note\":\"stub\"}");
    return buf;
}
const char *tool_wifi_scan(void) {
    static char buf[256];
    snprintf(buf, sizeof(buf), "{\"aps\":[{\"ssid\":\"demo\",\"rssi\":-40,\"ch\":6}],\"note\":\"stub\"}");
    return buf;
}
const char *tool_ir_send(const char *code_hex) {
    static char buf[128];
    snprintf(buf, sizeof(buf), "{\"ok\":true,\"sent\":\"%s\"}", code_hex ? code_hex : "");
    return buf;
}
const char *tool_imu_gesture(void) {
    static char buf[64];
    snprintf(buf, sizeof(buf), "{\"gesture\":\"none\"}");
    return buf;
}
void tools_menu_ble_radar(void) { ESP_LOGI(TAG, "Menu BLE radar"); }
void tools_menu_wifi(void) { ESP_LOGI(TAG, "Menu Wi-Fi"); }
