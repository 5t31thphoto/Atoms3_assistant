#pragma once
#define FOX_NAME "Ember"
#define FOX_MODE "groq"
#define FOX_COLOR_PRIMARY "#ff6b35"
