#pragma once
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
void audio_echo_init(void);
void audio_echo_set_volume(uint8_t percent);
int audio_echo_record(int16_t *buf, size_t samples, int timeout_ms);
int audio_echo_play(const int16_t *buf, size_t samples);
float audio_echo_last_amplitude(void);
void audio_echo_start_ptt(void);
void audio_echo_stop_ptt(void);
bool audio_echo_is_ptt_active(void);
