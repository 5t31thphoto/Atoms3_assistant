#include "llm_client.h"
#include "tools.h"
#include "esp_log.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
static const char *TAG = "llm";
static fox_config_t cfg;
void llm_client_init(const fox_config_t *c) { if (c) cfg = *c; ESP_LOGI(TAG, "mode=%s", cfg.mode); llm_client_register_tools(); }
void llm_client_register_tools(void) {}
static char *groq_chat(const char *user_text) {
    if (!cfg.groq_api_key[0]) return strdup("Need Groq API key.");
    char *r = malloc(256);
    if (r) snprintf(r, 256, "Hi! I'm %s (Groq stub). You said: %.80s", cfg.fox_name, user_text);
    return r;
}
static char *ondevice_chat(const char *user_text) {
    char *r = malloc(128);
    if (r) snprintf(r, 128, "(on-device stub) heard: %.60s", user_text);
    return r;
}
static char *stream_chat(const char *user_text) {
    char *r = malloc(128);
    if (r) snprintf(r, 128, "(stream stub) weights=%s", cfg.weights_url);
    return r;
}
char *llm_client_chat(const char *user_text) {
    if (!user_text) return NULL;
    if (!strcmp(cfg.mode, "ondevice")) return ondevice_chat(user_text);
    if (!strcmp(cfg.mode, "stream")) return stream_chat(user_text);
    return groq_chat(user_text);
}
