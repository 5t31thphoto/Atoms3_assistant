#pragma once
#include "config_store.h"
void llm_client_init(const fox_config_t *cfg);
char *llm_client_chat(const char *user_text);
void llm_client_register_tools(void);
