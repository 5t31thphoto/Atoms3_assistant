#pragma once
void fox_avatar_init(const char *name, const char *primary, const char *accent);
void fox_avatar_show_splash(const char *text);
void fox_avatar_set_emotion(const char *emotion);
void fox_avatar_set_mouth(float open);
void fox_avatar_tick(void);
