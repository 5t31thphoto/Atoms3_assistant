# Models
Drop Needle 2 / MimiModel / TinyStories quantized weights here for on-device mode.
For experimental stream, host chunks on a separate GitHub Pages repo.
