# Fox Voice Assistant — AtomS3R + Atomic Echo

Cute fox-powered voice AI for M5Stack AtomS3R + Atomic Echo Base.

This repo uses an **overlay zip** workflow:
1. Commit `fox-overlay.zip` at the repo root.
2. CI unzips it first (add/replace files, leave everything else alone).
3. Then builds firmware and publishes the flasher.

See `.github/workflows/build-firmware.yml`.
