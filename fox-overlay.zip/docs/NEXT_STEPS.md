# Next Steps
1. Wire real ES8311 / M5Atomic-EchoBase audio
2. Real Groq HTTP + tool_calls
3. Needle 2 / MimiModel on-device engine
4. Weight streaming protocol
5. 128x128 fox sprites + lip-sync
6. Real BLE + IMU radar plot
7. workflow_dispatch from the web UI (or soft-AP config)
