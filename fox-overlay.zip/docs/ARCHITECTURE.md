# Architecture

Overlay zip CI: repo may only contain `fox-overlay.zip` + this workflow.
CI unzips the overlay (add/replace, keep existing files), then builds.

Web flasher lives at repo root after unzip (`index.html`, `app.js`, `style.css`).
Firmware under `firmware/`.
